from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path


NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][-+]?\d+)?"


def number(value: str) -> float:
    return float(value.replace("D", "E").replace("d", "e"))


def last_labeled_value(text: str, labels: list[str]) -> float | None:
    matches: list[float] = []
    for label in labels:
        pattern = re.compile(rf"{label}\s*(?:=|:)\s*({NUMBER})", flags=re.IGNORECASE)
        matches.extend(number(match.group(1)) for match in pattern.finditer(text))
    return matches[-1] if matches else None


def parse_glstat(path: Path) -> dict:
    text = path.read_text(encoding="utf-8", errors="replace")
    return {
        "final_total_energy_ratio": last_labeled_value(
            text,
            [r"total energy\s*/\s*(?:initial energy|initial total energy)", r"energy ratio"],
        ),
        "final_kinetic_energy": last_labeled_value(text, [r"kinetic energy"]),
        "final_internal_energy": last_labeled_value(text, [r"internal energy"]),
        "final_hourglass_energy": last_labeled_value(text, [r"hourglass energy"]),
        "final_sliding_energy": last_labeled_value(text, [r"sliding interface energy", r"sliding energy"]),
        "final_added_mass": last_labeled_value(text, [r"added mass"]),
    }


def parse_termination(directory: Path) -> dict:
    texts = []
    for name in ("d3hsp", "messag", "mes0000"):
        path = directory / name
        if path.exists():
            texts.append(path.read_text(encoding="utf-8", errors="replace"))
    combined = "\n".join(texts)
    lower = combined.lower()
    compact = re.sub(r"\s+", "", lower)
    return {
        "normal_termination": "normaltermination" in compact,
        "error_termination": "errortermination" in compact or "fatalerror" in compact,
        "negative_volume_mentions": lower.count("negative volume"),
        "mass_scaling_mentions": lower.count("mass scaling"),
        "source_files_found": len(texts),
    }


def assess(termination: dict, glstat: dict) -> tuple[str, list[str]]:
    reasons: list[str] = []
    if not termination["normal_termination"] or termination["error_termination"]:
        reasons.append("solver did not demonstrate clean normal termination")
    if termination["negative_volume_mentions"]:
        reasons.append("negative-volume messages require case-level review")
    ratio = glstat.get("final_total_energy_ratio")
    if ratio is None:
        reasons.append("energy ratio unavailable")
    elif not 0.95 <= ratio <= 1.05:
        reasons.append(f"final energy ratio {ratio:.6g} outside preregistered candidate band [0.95, 1.05]")
    hourglass = glstat.get("final_hourglass_energy")
    internal = glstat.get("final_internal_energy")
    if hourglass is None or internal is None:
        reasons.append("hourglass/internal-energy ratio unavailable")
    elif abs(internal) > 0 and abs(hourglass / internal) > 0.05:
        reasons.append("hourglass/internal-energy magnitude exceeds candidate 5% gate")
    return ("pass" if not reasons else "review_or_fail"), reasons


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("result_dir", type=Path)
    parser.add_argument("--case-map", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    with args.case_map.open("r", encoding="utf-8", newline="") as handle:
        cases = list(csv.DictReader(handle))
    termination = parse_termination(args.result_dir)
    glstat_path = args.result_dir / "glstat"
    glstat = parse_glstat(glstat_path) if glstat_path.exists() else {}
    status, reasons = assess(termination, glstat)
    result = {
        "schema_version": "hf-p0-postprocess@1.0.0",
        "numerical_qa_status": status,
        "termination": termination,
        "global_statistics": glstat,
        "case_identity": cases,
        "limitations": [
            "Global ASCII QA is necessary but not sufficient for case-level perforation acceptance.",
            "Residual velocity and perforation state still require MATSUM/NODOUT and d3plot review.",
            "Candidate 5% gates are preregistered engineering checks, not universal LS-DYNA standards."
        ],
        "review_reasons": reasons,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

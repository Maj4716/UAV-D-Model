# SCNet / LS-DYNA 破片—装甲 P0 标定包

**状态：** 本地生成与静态校验阶段；求解器解析、数值收敛和物理有效性尚未成立。  
**证据等级上限：** `high_fidelity_synthetic_reference_candidate`。  
**单位制：** kg–mm–ms–kN–GPa–K，因此速度数值 `mm/ms` 与 `m/s` 相同。

本包用于资格检查当前项目的低层装甲响应模型。P0 在一份 LS-DYNA deck 中并列布置七个互不接触的四分之一对称子模型：五个速度点覆盖 1200–2600 m/s，三个网格层级检查 2000 m/s 中心工况的离散敏感性；中等网格中心工况被两者共享。

P0 固定为 8 g、10 mm、法向、立方体面迎击和 AISI 4340 Johnson–Cook 中心材料卡。四分之一对称只适用于这一中心切片。质量、厚度、斜入射、姿态和材料不确定性的 24 个 P1 三维工况已经在 `design/p1_preregistered_cases.csv` 中冻结，但只有 P0 通过求解器与数值 QA 后才允许提交。

## 本地生成与验证

```powershell
& 'D:\ProgramData\Anaconda\envs\pytorch312-lmdt\python.exe' scripts\generate_p0.py
& 'D:\ProgramData\Anaconda\envs\pytorch312-lmdt\python.exe' scripts\generate_p1_design.py
& 'D:\ProgramData\Anaconda\envs\pytorch312-lmdt\python.exe' scripts\validate_package.py
& 'D:\ProgramData\Anaconda\envs\pytorch312-lmdt\python.exe' scripts\selftest_keyword_format.py
& 'D:\ProgramData\Anaconda\envs\pytorch312-lmdt\python.exe' scripts\selftest_postprocessor.py
```

静态 `PASS` 只证明案例身份、哈希、长字段声明、数值字段宽度、全量关键字块基数、卡片数、字段数与 `I/F` 类型合同、网格引用、正的结构化六面体方向、初始间隙、离散体积/质量积分、P1 分层和必需关键词在本包内自洽。R01 因普通字段模式与 15–16 字符数值项冲突失败；R02 因必需卡片/字段不完整且 `PHASE` 类型错误失败；R03 虽补全卡片，却把 `*CONTROL_CONTACT` Card 2 的整数型 `ECDT` 写成浮点科学计数，且旧校验器漏检了该字段。R04 将 `ECDT` 显式序列化为整数，并对生成器输出的全部 23 种关键字、110 个关键字块实施逐卡逐字段合同检查。静态检查仍不能替代 LS-DYNA 实际解析，也不证明能量、接触、侵蚀或穿透结果合理。

## SCNet 提交合同

1. 使用平台的 LS-DYNA MPP 双精度模板；记录求解器完整 build、可执行文件身份、MPI 实现、队列、节点和 ranks。
2. P0 优先使用单节点，MPI ranks 与墙钟上限按平台模板、节点拓扑和队列规则现场绑定。资源不设人为硬上限，但必须记录申请值与实耗；只有求解器解析、内存或实测吞吐证据支持时才提高节点数或墙钟时间。
3. 上传 `decks/p0_velocity_mesh_calibration.k` 与 `decks/p0_case_part_map.csv`。平台模板直接运行 `.k` 时，不使用未绑定的通用 Slurm 脚本。
4. 提交前，把平台实际 solver cohort 写回 `manifest.json` 的 `solver` 字段，并保存最终 deck SHA-256。
5. 必须回传 `d3hsp`、`messag/mes*`、`glstat`、`matsum`、`sleout`、`nodout`、`d3plot*` 和 Slurm 标准输出/错误。

`artifacts/scnet_lsdyna_plate_calibration_p0_20261017.zip` 是审计与复现包；平台模板若直接接收 `.k`，应上传未压缩的 `decks/p0_velocity_mesh_calibration.k` 作为求解输入，而不是把 ZIP 当作输入 deck。

## 结果准入

P0 至少满足以下条件后，才能进入响应拟合：

- 正常终止且无未解释的 fatal/error termination；
- 总能量比候选范围 0.95–1.05；
- 小时玻璃能相对峰值内能的绝对比候选上限 5%；本 deck 使用全积分 S/R 实体，显著非零小时玻璃能需解释；
- 不使用质量缩放；若求解器报告附加质量，则 P0 拒绝；
- 负体积、删除单元、接触警告必须按 part 和工况解释；
- 三个网格层级的穿透状态一致，且中心工况剩余速度相对变化进入预注册误差带；
- 至少一个速度点未穿透、至少一个速度点穿透，否则 P1 前必须扩展速度边界。

这些阈值是本项目预注册的候选工程门，不是普遍适用的 LS-DYNA 标准。

## 与本地引擎的关系

P0 不直接输出 KMFC。通过的连续响应只用于拟合新的、版本化的装甲响应模型，包括 V50/转变宽度、残余速度和能量传递。现有 `demo_armor_response` 不覆盖；现有已观察 Test 不参与选参；P1 holdout 不参与材料卡或公式选择。

## 主要证据来源

- [SCNet LS-DYNA 使用说明](https://www.scnet.cn/help/docs/mainsite/hpc/software-examples/use/CAE/LSDYNA/index.html)
- [Ansys LS-DYNA Projectile 官方示例](https://lsdyna.ansys.com/projectile/)
- [Ansys LS-DYNA 结构冲击建议](https://lsdyna.ansys.com/recommendations-for-structural-impact-2/)
- [Ansys LS-DYNA Hourglass 说明](https://lsdyna.ansys.com/hourglass/)
- [Ansys LS-DYNA Total Energy 说明](https://lsdyna.ansys.com/total-energy-2/)
- [Johnson–Cook 1983 原始论文扫描件](https://ia600406.us.archive.org/4/items/AConstitutiveModelAndDataForMetals/A%20constitutive%20model%20and%20data%20for%20metals_text.pdf)

材料参数的逐字段来源与限制记录在 `materials/jc4340_reference.json`。
